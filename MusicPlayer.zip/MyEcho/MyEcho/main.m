//
//  main.m
//  MyEcho
//
//  Created by iceAndFire on 15/10/11.
//  Copyright © 20 e15年 free. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
