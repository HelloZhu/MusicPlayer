//
//  StingCell.m
//  MyEcho
//
//  Created by iceAndFire on 15/11/1.
//  Copyright © 2015年 free. All rights reserved.
//

#import "StingCell.h"

@implementation StingCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
