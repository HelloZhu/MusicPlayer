//
//  MyEchoCollectionCell.h
//  MyEcho
//
//  Created by iceAndFire on 15/10/26.
//  Copyright © 2015年 free. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyEchoCollectionCell : UICollectionViewCell

@property (nonatomic, strong) UIImageView *imageView;

@end
