//
//  PlayerImageView.h
//  MyEcho
//
//  Created by iceAndFire on 15/10/18.
//  Copyright © 2015年 free. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlayerImageView : UIImageView

#pragma mark - 属性
@property (nonatomic, strong) UIButton *playerButton;
@property (nonatomic, strong) NSMutableArray *array;

@end
