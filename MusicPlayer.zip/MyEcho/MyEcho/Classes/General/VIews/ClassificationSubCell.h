//
//  ClassificationSubCell.h
//  MyEcho
//
//  Created by iceAndFire on 15/10/28.
//  Copyright © 2015年 free. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ClassificationSubCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imgView;

@property (weak, nonatomic) IBOutlet UILabel *nameLabel;


@end
