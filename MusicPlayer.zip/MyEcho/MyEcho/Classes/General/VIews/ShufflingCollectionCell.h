//
//  ShufflingCollectionCell.h
//  MyEcho
//
//  Created by iceAndFire on 15/10/24.
//  Copyright © 2015年 free. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShufflingCollectionCell : UICollectionViewCell

//@property (nonatomic, strong) NSArray *imgArray;
@property (nonatomic, strong) SDCycleScrollView *cycleScrollView;

@end
