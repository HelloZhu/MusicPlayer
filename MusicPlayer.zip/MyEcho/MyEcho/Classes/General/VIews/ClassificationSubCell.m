//
//  ClassificationSubCell.m
//  MyEcho
//
//  Created by iceAndFire on 15/10/28.
//  Copyright © 2015年 free. All rights reserved.
//

#import "ClassificationSubCell.h"

@implementation ClassificationSubCell

- (void)awakeFromNib
{
    [super awakeFromNib];
    
//    self.imgView.backgroundColor = [UIColor randomColor];
}

@end
