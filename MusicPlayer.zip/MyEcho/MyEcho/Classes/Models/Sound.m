//
//  Sound.m
//  MyEcho
//
//  Created by iceAndFire on 15/10/17.
//  Copyright © 2015年 free. All rights reserved.
//

#import "Sound.h"

@implementation Sound

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
//    NSLog(@"sound undefinedKey ：%@",key);
}

@end
