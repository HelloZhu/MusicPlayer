//
//  Banner.h
//  MyEcho
//
//  Created by iceAndFire on 15/10/26.
//  Copyright © 2015年 free. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Banner : NSObject


@property (nonatomic, copy) NSString *create_user_id;
@property (nonatomic, copy) NSString *extension;
@property (nonatomic, copy) NSString *create_time;
@property (nonatomic, copy) NSString *sex;
@property (nonatomic, copy) NSString *end_time;
@property (nonatomic, copy) NSString *click_count;
@property (nonatomic, copy) NSString *pic;
@property (nonatomic, copy) NSString *turn;
@property (nonatomic, copy) NSString *type;
@property (nonatomic, copy) NSString *platform;
@property (nonatomic, copy) NSString *url;
@property (nonatomic, copy) NSString *content;
@property (nonatomic, copy) NSString *start_time;
@property (nonatomic, copy) NSString *ad_id;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *online;
@property (nonatomic, copy) NSString *ID;//id
@property (nonatomic, copy) NSString *show_count;
@property (nonatomic, copy) NSString *position;


@end
