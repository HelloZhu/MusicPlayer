//
//  User.h
//  MyEcho
//
//  Created by iceAndFire on 15/10/17.
//  Copyright © 2015年 free. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface User : NSObject

@property (nonatomic, copy) NSString *avatar;//
@property (nonatomic, copy) NSString *avatar_100;//
@property (nonatomic, copy) NSString *avatar_50;//
@property (nonatomic, copy) NSString *famous_status;//
@property (nonatomic, copy) NSString *followed_count;//
@property (nonatomic, copy) NSString *ID;//id
@property (nonatomic, copy) NSString *name;//
@property (nonatomic, copy) NSString *pay_class;//
@property (nonatomic, copy) NSString *pay_status;//
@property (nonatomic, copy) NSString *photo;//
@property (nonatomic, copy) NSString *status;//

@end
